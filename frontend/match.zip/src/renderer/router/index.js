import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
    routes: [
    {
        path: '/',
        redirect:'/frame'
    },
    {
        path: '/frame',
        component:resolve => require(['../frame.vue'],resolve),
        meta:
        {
            title:'导航栏'
        },
        props:true,
        redirect:'/home',
        children:
        [
        {
            path:'/home',
            name:'home',
            component:resolve =>require(['../components/page.vue'],resolve),
            meta:
            {
                title:'主页'
            },
            redirect:'/home/welcome',
            children:
            [
            {
                path:'/home/welcome',
                name:'welcome',
                component:resolve =>require(['../components/Welcome.vue'],resolve),
                meta:
                {
                    title:'Welcome'
                }
            },
            {
                path:'/home/test',
                name:'test',
                component:resolve =>require(['../components/test.vue'],resolve),
                meta:
                {
                    title:'test'
                }
            }
            ]
        }
        ]
    }]
})
