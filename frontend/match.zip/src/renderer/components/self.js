import Vue from 'vue';
let Self = new Vue;
export default Self;