<template>
  <div class="hello">
    <h1 id="h2">{{ msg }}</h1>
  </div>
</template>
 
<script>
export default {
  name: 'test',
  data () {
    return {
      msg: 'Testing'
    }
  }
}
</script>

<style type="text/css">
#h2 {
  font-family:Vladimir Script;
	text-align: center;
	color: #1f1f1f;
	font-size: 80px;
  margin-top: 100px;
  float: left;
  margin-left: 50px;
}
.hello
{
  width: 80%;
  margin-left: 10%;
}
</style>