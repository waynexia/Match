<template>
	<div id="bigPage">
		<div class="welcome">Welcome to MaTcH</div>
		<router-link to="/pdf">Start My Reading</router-link>
	</div>
</template>

<script>
	export default{
		name:"welcome",
		method:{
			
		}
	}
</script>

<style>
#bigPage
{
	height:100%;
	float: left;
	text-align: center;
}
#welcomeLogo
{
	width: 80%;
	height: 200px;
	margin-top: 15%;
}
.welcome
{
	font-size: 50px;
	font-family: Segoe UI;
}
</style>